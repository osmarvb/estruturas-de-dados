#include <stdio.h>

int main(){

    int a, b;

    // ENTRADA
    scanf("%d %d", &a, &b);
    
    // PROCESSAMENTO
    int multi = a * b;

    
    // SAÍDA
    printf("%d\n", multi);

    return 0;
}