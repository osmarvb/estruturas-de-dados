#include <stdio.h>

int main(){
    int a, b;

    // ENTRADA
    a = 1;
    b = 2;
    
    // PROCESSAMENTO
    int soma = a + b;
    
    // SAÍDA
    printf("%d\n", soma);

    return 0;
}
